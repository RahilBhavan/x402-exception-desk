"""Release automation package."""
